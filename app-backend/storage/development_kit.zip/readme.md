Install NodeJS from here - https://nodejs.org/en/

Extract the Zip file to your preferred location.

Open command prompt, navigate to the folder you have extracted the zip to,  type 'npm install live-server'

Once done , type 'node live_app.js' and it should launch the Development Kit.

Your application goes inside /app directory. Once finished , zip the directory and upload to the developer portal